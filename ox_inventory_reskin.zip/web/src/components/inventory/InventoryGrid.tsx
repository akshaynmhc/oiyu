import React, { useRef } from 'react';
import { Inventory } from '../../typings';
import WeightBar from '../utils/WeightBar';
import InventorySlot from './InventorySlot';
import { getTotalWeight } from '../../helpers';
import { useAppSelector } from '../../store';
import { selectLeftInventory } from '../../store/inventory';
import { useIntersection } from '../../hooks/useIntersection';
import { FaBoxOpen, FaBox, FaSuitcase } from "react-icons/fa";
import { TbTrashOff } from "react-icons/tb";
import { FaGears } from "react-icons/fa6";
import { PiShippingContainer } from "react-icons/pi";
import { LiaSearchengin } from "react-icons/lia";
import { AiOutlineShoppingCart } from "react-icons/ai";
import { FaCar } from "react-icons/fa";

const InventoryGrid: React.FC<{ inventory: Inventory, direction: 'left' | 'right' }> = ({ inventory, direction }) => {
  const weight = React.useMemo(
    () => (inventory.maxWeight !== undefined ? Math.floor(getTotalWeight(inventory.items) * 1000) / 1000 : 0),
    [inventory.maxWeight, inventory.items]
  );
  const isPlayerInventory = inventory.type === 'player';
  const [page, setPage] = React.useState(0);
  const containerRef = useRef(null);
  const { ref, entry } = useIntersection({ threshold: 0.5 });
  const isBusy = useAppSelector((state) => state.inventory.isBusy);

  React.useEffect(() => {
    if (entry && entry.isIntersecting) {
      setPage((prev) => ++prev);
    }
  }, [entry]);

  const getIconOrImage = () => {
    if (inventory.maxWeight == 96000 && inventory.type !== 'otherplayer' && inventory.type !== 'drop') {
    }
    switch (inventory.type) {
      case'player':
      return <FaBoxOpen className='inventory-icon'/>;
      case 'newdrop':
        return <TbTrashOff className='inventory-icon'/>;
      case 'drop':
        return <TbTrashOff className='inventory-icon'/>;
      case 'container':
        return <PiShippingContainer className='inventory-icon'/>;
      case 'crafting':
        return <FaGears className='inventory-icon'/>;
      case 'stash':
        return <FaBox className='inventory-icon'/>;
      case 'inspect':
        return <LiaSearchengin className='inventory-icon'/>;
      case 'otherplayer':
        return <FaSuitcase className='inventory-icon'/>;
      case 'shop':
        return <AiOutlineShoppingCart className='inventory-icon'/>;
      case 'trunk':
        return <FaCar className='inventory-icon'/>;
      case 'glovebox':
        return <FaCar className='inventory-icon'/>;
      default:
        return <FaBoxOpen className='inventory-icon'/>;
    }
  };
  
  return (
    <>
      <div className="inventory-grid-wrapper" style={{ pointerEvents: isBusy ? 'none' : 'auto' }}>
        <div>
          <div className="inventory-grid-header-wrapper">
          {getIconOrImage()}
            <p>{inventory.label}</p>
            {inventory.maxWeight && (
              <p className='weight-divide-text'>
                {weight / 1000}/{inventory.maxWeight / 1000}kg
              </p>
            )}
          </div>
          <WeightBar percent={inventory.maxWeight ? (weight / inventory.maxWeight) * 100 : 0} />
        </div>
        <div className={direction === 'left' ? 'inventory-grid-container-left' : 'inventory-grid-container-right'} ref={containerRef}>
          <>
            {inventory.items.map((item, index) => {
                if(index < 5 && inventory.type==='player') {
                  return ''
                }
                return <InventorySlot
                key={`${inventory.type}-${inventory.id}-${item.slot}`}
                item={item}
                inventoryType={inventory.type}
                inventoryGroups={inventory.groups}
                inventoryId={inventory.id}
              />
            })}
          </>
        </div>
      </div>
    </>
  );
};

export default InventoryGrid;
